import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

public class Read_Browser_Configuration {
	HSSFWorkbook ln_Obj_Workbook;
	HSSFCell ln_Obj_Cell;
	HSSFRow row;
	HSSFSheet sheet;
	int iterator;
	String Cellvalue;

	public int Read_BrowserConfiguartion() throws Exception {
		File gb_Obj_directory = new File(".");

		String gb_Str_Basepath = gb_Obj_directory.getCanonicalPath();
		int gb_Int_Location = gb_Str_Basepath.indexOf("CrossBrowserTesting");
		gb_Str_Basepath = gb_Str_Basepath.substring(0, gb_Int_Location);
		// getPath(); // driver.get("http://qaweb01.invoicecentral.com");
		//System.out.println(gb_Str_Basepath);

		@SuppressWarnings("unused")
		int Count = 0;

		FileInputStream fileInputStream = new FileInputStream(gb_Str_Basepath
				+ "TestData//Browser_Configuration.xls");

		POIFSFileSystem fsFileSystem = new POIFSFileSystem(fileInputStream);

		ln_Obj_Workbook = new HSSFWorkbook((fsFileSystem));

		sheet = ln_Obj_Workbook.getSheet("Browser_Configuration");
		return Count = sheet.getLastRowNum();

	}

	public String getcell_Stringvalue(int rowNumber, int cellNumber) {
		Cellvalue = null;
		row = sheet.getRow(rowNumber);
		ln_Obj_Cell = row.getCell(cellNumber);

		Cellvalue = ln_Obj_Cell.getStringCellValue();
		return Cellvalue;
	}
}
