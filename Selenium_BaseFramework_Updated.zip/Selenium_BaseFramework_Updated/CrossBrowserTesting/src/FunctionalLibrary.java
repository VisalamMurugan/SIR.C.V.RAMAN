import java.awt.AWTException;
import java.awt.Robot;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
//import org.apache.commons.jxpath.FunctionLibrary;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.Select;

public class FunctionalLibrary extends XmlReporting {
	boolean ElementPresence = false;
	boolean actionPerformed = false;
	int FailureScreenshotIterator = 0;
	int ManualScreenshotIterator = 0;
	static XmlReporting objxml;
	static File gb_Obj_directory;
	public static String gb_Str_Basepath;
	static int gb_Int_Location;
	File FileScreenShotFolder;
	static File FileResultFolder;
	static File source;
	static File desc;
	static HSSFRow row;
	static HSSFCell cell;
	static HSSFCell cell1;
	HSSFCell cell2;
	static HSSFWorkbook workbook;

	public static final String gb_Obj_Kill = "taskkill /IM ";
	private static final String TASKLIST = "tasklist";
	// private static final DefaultSelenium DefaultSelenium = null;
	DateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");

	// get current date time with Date()
	Date date = new Date();
	String timestamp = dateFormat.format(date).toString();

	public static void getPath() throws Exception {
		/*gb_Obj_directory = new File(".");

		gb_Str_Basepath = gb_Obj_directory.getCanonicalPath();
		gb_Int_Location = gb_Str_Basepath.indexOf("CrossBrowserTesting");
		gb_Str_Basepath = gb_Str_Basepath.substring(0, gb_Int_Location);*/

		gb_Obj_directory = new File(".");
		// System.out.println(gb_Obj_directory);

		gb_Str_Basepath = gb_Obj_directory.getCanonicalPath();
		System.out.println(gb_Str_Basepath);

		gb_Str_Basepath = gb_Str_Basepath + "\\..\\";
	}

	public void create_Folder() {

		FileScreenShotFolder = new File(gb_Str_Basepath + "Result"
				+ Driver_Script.gb_Str_Navi_Slash + Driver_Script.gb_Str_Os
				+ Driver_Script.gb_Str_Navi_Slash
				+ Driver_Script.gb_Str_TestcaseId
				+ Driver_Script.gb_Str_Navi_Slash + "FailureScreenshots_"
				+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp);

		if (!FileScreenShotFolder.exists()) {
			FileScreenShotFolder.mkdirs();
		}

	}

	public static void copy_xlst() {

		source = new File(gb_Str_Basepath + "Result"
				+ Driver_Script.gb_Str_Navi_Slash + "XLST");

		desc = new File(gb_Str_Basepath + "Result"
				+ Driver_Script.gb_Str_Navi_Slash + Driver_Script.gb_Str_Os
				+ Driver_Script.gb_Str_Navi_Slash
				+ Driver_Script.gb_Str_TestcaseId + "/" + "XLST");

		try {
			desc.mkdirs();
			FileUtils.copyDirectory(source, desc);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void check_Folder() throws IOException {

		FileResultFolder = new File(gb_Str_Basepath + "Result"
				+ Driver_Script.gb_Str_Navi_Slash + Driver_Script.gb_Str_Os);

		if (!FileResultFolder.exists()) {

			FileResultFolder.mkdirs();
		}

		FileResultFolder = new File(gb_Str_Basepath + "Result"
				+ Driver_Script.gb_Str_Navi_Slash + Driver_Script.gb_Str_Os
				+ Driver_Script.gb_Str_Navi_Slash
				+ Driver_Script.gb_Str_TestcaseId);

		if (!FileResultFolder.exists()) {

			FileResultFolder.mkdirs();
			copy_xlst();
		}
	}

	public static void check_Manual_SnapshotFolder() throws Exception {
		getPath();
		FileResultFolder = new File(gb_Str_Basepath + "Manual"
				+ Driver_Script.gb_Str_Navi_Slash + Driver_Script.gb_Str_Os);

		if (!FileResultFolder.exists()) {

			FileResultFolder.mkdirs();
		}
		FileResultFolder = new File(gb_Str_Basepath + "Manual"
				+ Driver_Script.gb_Str_Navi_Slash + Driver_Script.gb_Str_Os
				+ Driver_Script.gb_Str_Navi_Slash
				+ Driver_Script.gb_Str_TestcaseId);

		if (!FileResultFolder.exists()) {

			FileResultFolder.mkdirs();
		}

		FileResultFolder = new File(gb_Str_Basepath + "Manual"
				+ Driver_Script.gb_Str_Navi_Slash + Driver_Script.gb_Str_Os
				+ Driver_Script.gb_Str_Navi_Slash
				+ Driver_Script.gb_Str_TestcaseId
				+ Driver_Script.gb_Str_Navi_Slash
				+ Driver_Script.gb_Str_Browser + "_"
				+ Driver_Script.gb_Str_Version);

		if (!FileResultFolder.exists()) {

			FileResultFolder.mkdirs();
		}
	}

	public static void killProcess(String serviceName) throws Exception {

		Runtime.getRuntime().exec(gb_Obj_Kill + serviceName);
	}

	public static boolean isProcessRunging(String serviceName) throws Exception {
		Boolean a = null;
		Process s = Runtime.getRuntime().exec(TASKLIST);
		BufferedReader reader1 = new BufferedReader(new InputStreamReader(
				s.getInputStream()));
		String line;

		while ((line = reader1.readLine()) != null) {
			if (line.contains(serviceName)) {
				a = true;
				break;
			} else {
				a = false;
			}
		}
		if (a == true) {
			killProcess(serviceName);
			return true;
		}
		return false;
	}

	public static void certificate(WebDriver gb_Obj_Driver,
			String gb_Str_Browser) throws InterruptedException, AWTException {
		Thread.sleep(10000);
		WebElement element = null;
		if (gb_Str_Browser.toUpperCase().trim().equals("IE")) {
			try {
				element = gb_Obj_Driver
						.findElement(By
								.linkText("Continue to this website (not recommended)."));

				if (element.isDisplayed())
					element.click();
			} catch (Exception e) {
			}
		} else if ((gb_Str_Browser.toUpperCase().trim().equals("GC"))
				|| (gb_Str_Browser.toUpperCase().trim().equals("SAFARI"))) {
			// Selenium.runScript("window.blur();");
			// Selenium.runScript("setTimeout(window.focus, 0);");
			// Selenium.getEval("window.resizeTo(screen.availWidth, screen.availHeight)");
			Robot bot = new Robot();
			bot.mouseMove(50, 100);
			bot.mousePress(java.awt.event.InputEvent.BUTTON1_MASK);
			bot.mouseRelease(java.awt.event.InputEvent.BUTTON1_MASK);
			/*
			 * element =
			 * gb_Obj_Driver.findElement(By.linkText("Proceed anyway")); if
			 * (element.isDisplayed()) element.click();
			 */
		}

	}

	/*
	 * public void key_Press(DefaultSelenium selenium, String presskey) { try {
	 * selenium.keyPressNative(presskey); } catch (Exception e) { } }
	 */

	public void key_Press(WebDriver gb_Obj_Driver, String presskey) {
		try {
			Actions action = new Actions(gb_Obj_Driver);
			action.sendKeys(presskey);
		} catch (Exception e) {
		}
	}

	public void CaptureScreenshot(WebDriver gb_Obj_Driver, String FileName) {
		try {

			File scrFile = ((TakesScreenshot) gb_Obj_Driver)
					.getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(FileName));
			// selenium.captureScreenshot(FileName);
		} catch (Exception e) {
		}
	}

	/*
	 * public void open(DefaultSelenium selenium, String Url) { try {
	 * selenium.open(Url, "true"); } catch (Exception e) { } }
	 * 
	 * public void Focus(DefaultSelenium selenium, String Locator) {
	 * 
	 * try { selenium.focus(Locator); } catch (Exception e) { } }
	 * 
	 * public void WindowFocus(DefaultSelenium selenium) {
	 * 
	 * try { selenium.windowFocus(); } catch (Exception e) { } }
	 */

	public void WindowMaximize(WebDriver gb_Obj_Driver) {
		try {
			gb_Obj_Driver.manage().window().maximize();
			// selenium.windowMaximize();
		} catch (Exception e) {
		}
	}

	public void Close(WebDriver gb_Obj_Driver) {

		try {
			gb_Obj_Driver.close();
		} catch (Exception e) {
		}
	}

	public boolean sendKeys(String objName, String objReadableName,
			String value, String teststepNumber, WebDriver gb_Obj_Driver)
			throws Exception {

		WebElement element = GetwebLocators(gb_Obj_Driver, objName);
		try {
			
			element.clear();
			element.sendKeys(value);
			actionPerformed = true;
			objxml.CreateReport(teststepNumber, "Set the value: " + value
					+ " in the " + objReadableName, "The value: " + value
					+ " is set in the " + objReadableName, "Pass", "");
		} catch (Exception e) {
			System.out.println(8);
			getPath();
			create_Folder();
			FailureScreenshotIterator++;
			String Title = gb_Obj_Driver.getTitle();
			// String Title = selenium.getTitle();
			String Path;

			Path = gb_Str_Basepath + "Result" + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_Os + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_TestcaseId
					+ Driver_Script.gb_Str_Navi_Slash + "/FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp
					+ Driver_Script.gb_Str_Navi_Slash + Title
					+ FailureScreenshotIterator + ".png";

			CaptureScreenshot(gb_Obj_Driver, Path);
			String FileName = "FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp + "\\"
					+ Title + FailureScreenshotIterator + ".png";

			objxml.CreateReport(teststepNumber, "Set the value: " + value
					+ " in the " + objReadableName, "The value: " + value
					+ " is not set in the " + objReadableName, "Fail", FileName);
			actionPerformed = false;
		}
		return actionPerformed;
	}

	public boolean SetText(String objName, String objReadableName,
			String value, String teststepNumber, WebDriver gb_Obj_Driver)
			throws Exception {
		WebElement element = GetwebLocators(gb_Obj_Driver, objName);
		try {
			/*
			 * selenium.highlight(objName); selenium.type(objName, value);
			 */
			element.clear();
			element.sendKeys(value);
			actionPerformed = true;
			objxml.CreateReport(teststepNumber, "Set the value: " + value
					+ " in the " + objReadableName, "The value: " + value
					+ " is set in the " + objReadableName, "Pass", "");
		} catch (Exception e) {
			System.out.println(8);
			getPath();
			create_Folder();
			FailureScreenshotIterator++;
			String Title = gb_Obj_Driver.getTitle();
			// String Title = selenium.getTitle();
			String Path;

			Path = gb_Str_Basepath + "Result" + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_Os + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_TestcaseId
					+ Driver_Script.gb_Str_Navi_Slash + "/FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp
					+ Driver_Script.gb_Str_Navi_Slash + Title
					+ FailureScreenshotIterator + ".png";

			CaptureScreenshot(gb_Obj_Driver, Path);
			String FileName = "FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp + "\\"
					+ Title + FailureScreenshotIterator + ".png";

			objxml.CreateReport(teststepNumber, "Set the value: " + value
					+ " in the " + objReadableName, "The value: " + value
					+ " is not set in the " + objReadableName, "Fail", FileName);
			actionPerformed = false;
		}
		return actionPerformed;
	}

	public boolean SetTextTypekeys(String objName, String objReadableName,
			String value, String teststepNumber, WebDriver gb_Obj_Driver)
			throws Exception {
		WebElement element = GetwebLocators(gb_Obj_Driver, objName);
		try {
			if ((Driver_Script.gb_Str_Browser.toUpperCase().trim().equals("FF"))) {
				// selenium.getEval("selenium.browserbot.findElement('" +
				// objName + "').value='"+value+"';");
				/*
				 * Runtime r = Runtime.getRuntime(); try { r.exec(
				 * "\\\\172.25.114.206\\Honeywell_Automation_Rescripting\\VBSFILES\\Prod_Config_focus.exe"
				 * ); } catch (Exception e) {
				 * System.out.println(e.getMessage()); } Robot bot = new
				 * Robot(); selenium.highlight(objName);
				 * selenium.focus(objName); Thread.sleep(3000);
				 * selenium.typeKeys(objName, value);
				 * if(!(selenium.getText(objName).equals(value))) { for (int i =
				 * 0; i < value.length(); i++) { Thread.sleep(500);
				 * bot.keyPress(value.charAt(i)); }
				 */
				actionPerformed = true;
			} else {
				// selenium.highlight(objName);
				// selenium.type(value);
				element.sendKeys(value);
				actionPerformed = true;
			}
			objxml.CreateReport(teststepNumber, "Set the value: " + value
					+ " in the " + objReadableName, "The value: " + value
					+ " is set in the " + objReadableName, "Pass", "");
		} catch (Exception e) {
			getPath();
			create_Folder();
			FailureScreenshotIterator++;
			String Title = gb_Obj_Driver.getTitle();
			String Path;

			Path = gb_Str_Basepath + "Result" + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_Os + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_TestcaseId
					+ Driver_Script.gb_Str_Navi_Slash + "/FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp
					+ Driver_Script.gb_Str_Navi_Slash + Title
					+ FailureScreenshotIterator + ".png";

			CaptureScreenshot(gb_Obj_Driver, Path);
			String FileName = "FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp + "\\"
					+ Title + FailureScreenshotIterator + ".png";
			objxml.CreateReport(teststepNumber, "Set the value: " + value
					+ " in the " + objReadableName, "The value: " + value
					+ " is not set in the " + objReadableName, "Fail", FileName);
			actionPerformed = false;
		}
		return actionPerformed;
	}

	public void ManualScreenshot(WebDriver gb_Obj_Driver) throws Exception {
		if (Driver_Script.gb_str_ManualStatus.toUpperCase().trim()
				.equals("YES")) {
			getPath();
			ManualScreenshotIterator++;
			String Title = gb_Obj_Driver.getTitle();
			String Path;
			Path = gb_Str_Basepath + "Manual" + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_Os + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_TestcaseId
					+ Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_Browser + "_"
					+ Driver_Script.gb_Str_Version
					+ Driver_Script.gb_Str_Navi_Slash + Title
					+ ManualScreenshotIterator + ".png";
			CaptureScreenshot(gb_Obj_Driver, Path);
		}
	}

	public boolean Click(String objName, String objReadableName,
			String testStepNumber, WebDriver gb_Obj_Driver) throws Exception {
		try {

			ManualScreenshot(gb_Obj_Driver);

			WebElement element = GetwebLocators(gb_Obj_Driver, objName);
			// if(element.isVisible())
			// JavascriptExecutor javaSc = (JavascriptExecutor)gb_Obj_Driver;
			// javaSc.executeScript("arguments[0].click();",element);
			element.click();
			actionPerformed = true;
			objxml.CreateReport(testStepNumber, "Click on " + objReadableName,
					"Clicked  on " + objReadableName, "Pass", "");
		} catch (Exception e) {

			System.out.println(e);
			// } else
			{
				getPath();
				create_Folder();
				FailureScreenshotIterator++;
				String Title = gb_Obj_Driver.getTitle();
				String Path;
				Path = gb_Str_Basepath + "Result"
						+ Driver_Script.gb_Str_Navi_Slash
						+ Driver_Script.gb_Str_Os
						+ Driver_Script.gb_Str_Navi_Slash
						+ Driver_Script.gb_Str_TestcaseId
						+ Driver_Script.gb_Str_Navi_Slash
						+ "/FailureScreenshots_"
						+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp
						+ Driver_Script.gb_Str_Navi_Slash + Title
						+ FailureScreenshotIterator + ".png";
				CaptureScreenshot(gb_Obj_Driver, Path);
				String FileName = "FailureScreenshots_"
						+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp
						+ "\\" + Title + FailureScreenshotIterator + ".png";
				objxml.CreateReport(testStepNumber, "Click on "
						+ objReadableName, "Did not click on "
						+ objReadableName, "Fail", FileName);
				actionPerformed = false;
			}

		}

		return actionPerformed;
	}

	public boolean ClickSafari(String objName, String objReadableName,
			String testStepNumber, WebDriver gb_Obj_Driver) throws Exception {
		try {

			WebElement element = GetwebLocators(gb_Obj_Driver, objName);
			if (Driver_Script.gb_Str_Browser.toUpperCase().trim()
					.equals("SAFARI")) {
				ManualScreenshot(gb_Obj_Driver);
				new Actions(gb_Obj_Driver).moveToElement(element).perform();
				Thread.sleep(1000);
				Actions action = new Actions(gb_Obj_Driver);
				action.keyDown(Keys.ENTER).perform();
				actionPerformed = true;
			} else {
				ManualScreenshot(gb_Obj_Driver);
				element.click();
				actionPerformed = true;
			}
			objxml.CreateReport(testStepNumber, "Click on " + objReadableName,
					"Clicked  on " + objReadableName, "Pass", "");

		} catch (Exception e) {
			getPath();
			create_Folder();
			FailureScreenshotIterator++;
			String Title = gb_Obj_Driver.getTitle();
			String Path;
			Path = gb_Str_Basepath + "Result" + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_Os + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_TestcaseId
					+ Driver_Script.gb_Str_Navi_Slash + "/FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp
					+ Driver_Script.gb_Str_Navi_Slash + Title
					+ FailureScreenshotIterator + ".png";
			CaptureScreenshot(gb_Obj_Driver, Path);
			String FileName = "FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp + "\\"
					+ Title + FailureScreenshotIterator + ".png";
			objxml.CreateReport(testStepNumber, "Click on " + objReadableName,
					"Did not click on " + objReadableName, "Fail", FileName);
			actionPerformed = false;
		}
		return actionPerformed;
	}

	public boolean Select(String objName, String objReadableName, String value,
			String testStepNumber, WebDriver gb_Obj_Driver, String SheetName)
			throws Exception {

		WebElement element = GetwebLocators(gb_Obj_Driver, objName);
		try {
			ManualScreenshot(gb_Obj_Driver);
			if (element.isDisplayed()) {
				Select dropdown = new Select(element);
				dropdown.selectByVisibleText(value);
				actionPerformed = true;

			}
			actionPerformed = true;
			objxml.CreateReport(testStepNumber, "Select the value: " + value
					+ " in the " + objReadableName + " field", "The value: "
					+ value + " was selected in the " + objReadableName
					+ " field", "Pass", "");

		} catch (Exception e) {
			getPath();
			create_Folder();
			FailureScreenshotIterator++;
			String Title = gb_Obj_Driver.getTitle();
			String Path;
			Path = gb_Str_Basepath + "Result" + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_Os + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_TestcaseId
					+ Driver_Script.gb_Str_Navi_Slash + "/FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp
					+ Driver_Script.gb_Str_Navi_Slash + Title
					+ FailureScreenshotIterator + ".png";
			CaptureScreenshot(gb_Obj_Driver, Path);
			String FileName = "FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp + "\\"
					+ Title + FailureScreenshotIterator + ".png";
			objxml.CreateReport(testStepNumber, "Select the value: " + value
					+ " from the " + objReadableName + " field", "The value: "
					+ value + " was not selected in the " + objReadableName
					+ " field", "Fail", FileName);
			actionPerformed = false;
		}
		return actionPerformed;
	}

	public boolean SelectSafari(String objName, String objReadableName,
			String value, String testStepNumber, WebDriver gb_Obj_Driver,
			String SheetName) throws Exception {
		WebElement element = GetwebLocators(gb_Obj_Driver, objName);
		try {

			ManualScreenshot(gb_Obj_Driver);
			Select dropdown = new Select(element);
			Thread.sleep(3000);
			System.out.println("Inside Select Safari"
					+ getValue(SheetName, value));
			dropdown.selectByVisibleText(getValue(SheetName, value));
			actionPerformed = true;

			objxml.CreateReport(testStepNumber, "Select the value: " + value
					+ " in the " + objReadableName + " field", "The value: "
					+ value + " was selected in the " + objReadableName
					+ " field", "Pass", "");

		} catch (Exception e) {
			getPath();
			create_Folder();
			FailureScreenshotIterator++;
			String Title = gb_Obj_Driver.getTitle();
			String Path;
			Path = gb_Str_Basepath + "Result" + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_Os + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_TestcaseId
					+ Driver_Script.gb_Str_Navi_Slash + "/FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp
					+ Driver_Script.gb_Str_Navi_Slash + Title
					+ FailureScreenshotIterator + ".png";
			CaptureScreenshot(gb_Obj_Driver, Path);
			String FileName = "FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp + "\\"
					+ Title + FailureScreenshotIterator + ".png";
			objxml.CreateReport(testStepNumber, "Select the value: " + value
					+ " from the " + objReadableName + " field", "The value: "
					+ value + " was not selected in the " + objReadableName
					+ " field", "Fail", FileName);
			actionPerformed = false;
		}
		return actionPerformed;
	}

	public boolean IsElementPresent(String objName, WebDriver gb_Obj_Driver,
			String testStepNumber, String actual, String expected,
			String actualfailure) throws Exception {
		WebElement element = GetwebLocators(gb_Obj_Driver, objName);
		try {
			ElementPresence = element.isDisplayed();
			if (ElementPresence) {
				objxml.CreateReport(testStepNumber, expected, actual, "Pass",
						"");

			} else {
				getPath();
				create_Folder();
				FailureScreenshotIterator++;
				/*
				 * WebElement element =
				 * gb_Obj_Driver.findElement(By.tagName("input")); String Title
				 * = element.getAttribute("title");
				 */
				String Title = gb_Obj_Driver.getTitle();
				// String Title = selenium.getTitle();
				String Path;
				Path = gb_Str_Basepath + "Result"
						+ Driver_Script.gb_Str_Navi_Slash
						+ Driver_Script.gb_Str_Os
						+ Driver_Script.gb_Str_Navi_Slash
						+ Driver_Script.gb_Str_TestcaseId
						+ Driver_Script.gb_Str_Navi_Slash
						+ "/FailureScreenshots_"
						+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp
						+ Driver_Script.gb_Str_Navi_Slash + Title
						+ FailureScreenshotIterator + ".png";
				CaptureScreenshot(gb_Obj_Driver, Path);
				String FileName = "FailureScreenshots_"
						+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp
						+ "\\" + Title + FailureScreenshotIterator + ".png";
				objxml.CreateReport(testStepNumber, expected, actualfailure,
						"Fail", FileName);
			}

		} catch (Exception e) {
		}
		return ElementPresence;
	}

	public void writeReport(String teststepNumber, String Expected,
			String Actual, String Result) throws Exception {

		objxml.CreateReport(teststepNumber, Expected, Actual, Result, "");
	}

	public boolean SelectFrame(String objName, String objReadableName,
			String testStepNumber, WebDriver gb_Obj_Driver) throws Exception {
		try {
			//gb_Obj_Driver.switchTo().frame(GetwebLocators(gb_Obj_Driver, objName));
			gb_Obj_Driver.switchTo().frame(objName);
			// selenium.selectFrame(objName);
			actionPerformed = true;
			objxml.CreateReport(testStepNumber, "Select the frame"
					+ objReadableName, "The frame: " + objReadableName
					+ " was selected", "Pass", "");

		} catch (Exception e) {
			getPath();
			create_Folder();
			FailureScreenshotIterator++;
			String Title = gb_Obj_Driver.getTitle();
			String Path;
			Path = gb_Str_Basepath + "Result" + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_Os + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_TestcaseId
					+ Driver_Script.gb_Str_Navi_Slash + "/FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp
					+ Driver_Script.gb_Str_Navi_Slash + Title
					+ FailureScreenshotIterator + ".png";
			CaptureScreenshot(gb_Obj_Driver, Path);
			String FileName = "FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp + "\\"
					+ Title + FailureScreenshotIterator + ".png";
			objxml.CreateReport(testStepNumber, "Select the frame"
					+ objReadableName, "The frame: " + objReadableName
					+ " was not selected", "Fail", FileName);
			actionPerformed = false;
		}
		return actionPerformed;

	}

	public int GetText(String objName, String ComparsionString,
			String testStepNumber, String actual, String expected,
			String actual1, WebDriver gb_Obj_Driver) throws Exception {
		String retrievedText = null;
		WebElement element = GetwebLocators(gb_Obj_Driver, objName);
		// retrievedText = selenium.getText(objName);

		retrievedText = element.getText();
		if (retrievedText.trim().equals(ComparsionString)) {
			objxml.CreateReport(testStepNumber, expected, actual, "Pass", "");
			return 0;
		} else {
			getPath();
			create_Folder();
			FailureScreenshotIterator++;
			String Title = gb_Obj_Driver.getTitle();
			String Path;
			Path = gb_Str_Basepath + "Result" + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_Os + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_TestcaseId
					+ Driver_Script.gb_Str_Navi_Slash + "/FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp
					+ Driver_Script.gb_Str_Navi_Slash + Title
					+ FailureScreenshotIterator + ".png";
			CaptureScreenshot(gb_Obj_Driver, Path);
			String FileName = "FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp + "\\"
					+ Title + FailureScreenshotIterator + ".png";
			objxml.CreateReport(testStepNumber, expected, actual1
					+ "  The retrived value is: " + retrievedText, "Fail",
					FileName);
			actionPerformed = false;
			return 1;
		}

	}

	public void IsTextPresent(String ObjName, String testStepNumber,
			String actual, String expected, String actual1,
			WebDriver gb_Obj_Driver) {

		try {

			if (gb_Obj_Driver.getPageSource().contains(ObjName)) {
				objxml.CreateReport(testStepNumber, actual, expected, "Pass",
						"");
			}

			else {
				objxml.CreateReport(testStepNumber, expected, actual1, "Fail",
						"");
			}
		} catch (Exception e) {
		}

	}

	public boolean SelectWindow(String objName, String objReadableName,
			String testStepNumber, WebDriver gb_Obj_Driver) throws Exception {
		try {
			gb_Obj_Driver.switchTo().window(objName);
			// to switch to the default again.
			// driver.switchTo().defaultContent();
			// selenium.selectWindow(objName);
			actionPerformed = true;
			objxml.CreateReport(testStepNumber, "Select the window: "
					+ objReadableName, "The window: " + objReadableName
					+ " was selected", "Pass", "");

		} catch (Exception e) {
			getPath();
			create_Folder();
			FailureScreenshotIterator++;
			String Title = gb_Obj_Driver.getTitle();
			String Path;
			Path = gb_Str_Basepath + "Result" + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_Os + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_TestcaseId
					+ Driver_Script.gb_Str_Navi_Slash + "/FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp
					+ Driver_Script.gb_Str_Navi_Slash + Title
					+ FailureScreenshotIterator + ".png";
			CaptureScreenshot(gb_Obj_Driver, Path);
			String FileName = "FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp + "\\"
					+ Title + FailureScreenshotIterator + ".png";
			objxml.CreateReport(testStepNumber, "Select the window: "
					+ objReadableName, "The window: " + objReadableName
					+ " was not selected ", "Fail", FileName);
			actionPerformed = false;
		}
		return actionPerformed;

	}

	public boolean ConfirmationDialog(WebDriver gb_Obj_Driver,
			String testStepNumber, String actual, String expected,
			String actual1) throws Exception {
		// WebDriverWait wait = new WebDriverWait(gb_Obj_Driver, 300 /*timeout
		// in seconds*/);
		// if(wait.until(ExpectedConditions.alertIsPresent())!=null){
		/*
		 * if (selenium.isConfirmationPresent()) { selenium.getConfirmation();
		 */

		try {
			Alert alert = gb_Obj_Driver.switchTo().alert();
			actionPerformed = true;
			alert.accept();
			objxml.CreateReport(testStepNumber, expected, actual, "Pass", "");
		} catch (NoAlertPresentException ex) {
			getPath();
			create_Folder();
			FailureScreenshotIterator++;
			String Title = gb_Obj_Driver.getTitle();
			String Path;
			Path = gb_Str_Basepath + "Result" + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_Os + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_TestcaseId
					+ Driver_Script.gb_Str_Navi_Slash + "/FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp
					+ Driver_Script.gb_Str_Navi_Slash + Title
					+ FailureScreenshotIterator + ".png";
			CaptureScreenshot(gb_Obj_Driver, Path);
			String FileName = "FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp + "\\"
					+ Title + FailureScreenshotIterator + ".png";
			objxml.CreateReport(testStepNumber, actual1, expected, "Fail",
					FileName);
			actionPerformed = false;
		}
		return actionPerformed;

	}

	public String getText(String ObjName, WebDriver gb_Obj_Driver)
			throws Exception {
		String textvalue = "";
		WebElement element = GetwebLocators(gb_Obj_Driver, ObjName);
		try {

			textvalue = element.getText();

		} catch (Exception e) {
		}
		return textvalue;
	}

	public void CreateXml(String Version, String Environment, String Browser,
			String TestcaseID) throws Exception {
		objxml = new XmlReporting();
		objxml.InitializeReport(Version, Environment, Browser, TestcaseID);
	}

	public int WaitForElementPresent(String objName, String TestStepNumber,
			String objDesc, WebDriver gb_Obj_Driver) throws Exception {

		int waittime;
		boolean elementPresent = false;
		WebElement element = GetwebLocators(gb_Obj_Driver, objName);
		/*
		 * WebDriverWait wait = new WebDriverWait(gb_Obj_Driver, 60);
		 * wait.until(ExpectedConditions.presenceOfElementLocated(By.id("")));
		 */
		if (element == null) {
			getPath();
			create_Folder();
			FailureScreenshotIterator++;
			String Title = gb_Obj_Driver.getTitle();
			String Path;
			Path = gb_Str_Basepath + "Result" + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_Os + Driver_Script.gb_Str_Navi_Slash
					+ Driver_Script.gb_Str_TestcaseId
					+ Driver_Script.gb_Str_Navi_Slash + "/FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp
					+ Driver_Script.gb_Str_Navi_Slash + Title
					+ FailureScreenshotIterator + ".png";

			CaptureScreenshot(gb_Obj_Driver, Path);

			String FileName = "FailureScreenshots_"
					+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp + "\\"
					+ Title + FailureScreenshotIterator + ".png";

			objxml.CreateReport(TestStepNumber, "The element " + objDesc
					+ " Should be Present", "The element " + objDesc
					+ "is not Present", "Fail", FileName);

			actionPerformed = false;

			return 1;
		}

		else {
			waittime = 10000;

			for (int second = 0;; second++) {
				try {
					elementPresent = element.isDisplayed();
				} catch (Exception e) {
				}
				if (elementPresent == true) {

					return 0;
				}
				if (second >= waittime && elementPresent == false) {

					getPath();
					create_Folder();
					FailureScreenshotIterator++;
					String Title = gb_Obj_Driver.getTitle();
					// String Title = gb_Obj_selenium.getTitle();
					String Path;
					Path = gb_Str_Basepath + "Result"
							+ Driver_Script.gb_Str_Navi_Slash
							+ Driver_Script.gb_Str_Os
							+ Driver_Script.gb_Str_Navi_Slash
							+ Driver_Script.gb_Str_TestcaseId
							+ Driver_Script.gb_Str_Navi_Slash
							+ "/FailureScreenshots_"
							+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp
							+ Driver_Script.gb_Str_Navi_Slash + Title
							+ FailureScreenshotIterator + ".png";

					CaptureScreenshot(gb_Obj_Driver, Path);

					String FileName = "FailureScreenshots_"
							+ Driver_Script.gb_Str_TestcaseId + "_" + timestamp
							+ "\\" + Title + FailureScreenshotIterator + ".png";

					objxml.CreateReport(TestStepNumber, "The element "
							+ objDesc + " Should be Present", "The element "
							+ objDesc + "is not Present", "Fail", FileName);

					actionPerformed = false;

					return 1;

				}
				Thread.sleep(3000);
			}
		}
	}

	public static String getLocator(String SheetName, String Name)
			throws Exception {
		int i = 0;
		try {
			getPath();
			FileInputStream fileInputStream = null;
			int iterator;
			int UsedCellCount = 0;
			if (Driver_Script.gb_Str_TestcaseId.contains("HFS")) {
				fileInputStream = new FileInputStream(gb_Str_Basepath
						+ "TestData//HFS_Application_Input.xls");

			} else if (Driver_Script.gb_Str_TestcaseId.contains("HLS")) {
				fileInputStream = new FileInputStream(gb_Str_Basepath
						+ "TestData//HLS_Application_Input.xls");

			} else if (Driver_Script.gb_Str_TestcaseId.contains("S&C")) {
				fileInputStream = new FileInputStream(gb_Str_Basepath
						+ "TestData//S&C_Application_Input.xls");

			}

			POIFSFileSystem fsFileSystem = new POIFSFileSystem(fileInputStream);

			workbook = new HSSFWorkbook((fsFileSystem));

			HSSFSheet sheet = workbook.getSheet(SheetName);
			UsedCellCount = sheet.getLastRowNum();
			for (iterator = 1; iterator <= (UsedCellCount); iterator++) {
				row = sheet.getRow(iterator);
				cell = row.getCell(0);
				cell1 = row.getCell(1);

				if (cell.getStringCellValue().equals(Name)) {
					cell1 = row.getCell(1);
					i = 1;
					break;
				}
			}
			if (i == 0) {
				System.out.println("Excel Value : " + Name + "Not Found");
				throw new Exception();
			}
		} catch (Exception e) {
			System.out.println("Excel Value : " + Name);
			throw new Exception(e);

		}

		return cell1.getStringCellValue();
	}

	public static String getValue(String SheetName, String Value)
			throws Exception {
		int i = 0;
		try {
			getPath();
			FileInputStream fileInputStream = null;
			int iterator;
			int UsedCellCount = 0;
			if (Driver_Script.gb_Str_TestcaseId.contains("HFS")) {
				fileInputStream = new FileInputStream(gb_Str_Basepath
						+ "TestData//HFS_Application_Input.xls");

			} else if (Driver_Script.gb_Str_TestcaseId.contains("HLS")) {
				fileInputStream = new FileInputStream(gb_Str_Basepath
						+ "TestData//HLS_Application_Input.xls");

			} else if (Driver_Script.gb_Str_TestcaseId.contains("S&C")) {
				fileInputStream = new FileInputStream(gb_Str_Basepath
						+ "TestData//S&C_Application_Input.xls");

			}

			POIFSFileSystem fsFileSystem = new POIFSFileSystem(fileInputStream);

			workbook = new HSSFWorkbook((fsFileSystem));
			HSSFSheet sheet = workbook.getSheet(SheetName);
			UsedCellCount = sheet.getLastRowNum();

			for (iterator = 1; iterator <= (UsedCellCount); iterator++) {
				row = sheet.getRow(iterator);
				cell = row.getCell(0);
				// cell1 = row.getCell(2);

				if (cell.getStringCellValue().equals(Value)) {
					if (SheetName.equals("Application")) {
						cell1 = row.getCell(2);
					} else {
						cell1 = row.getCell(Driver_Script.CurrentIteration + 2);

					}
					i = 1;
					break;
				}
			}
			if (i == 0) {
				System.out.println("Excel Value : " + Value + "Not Found");
				throw new Exception();
			}
		} catch (Exception e) {
			System.out.println("Excel Value : " + Value);
			System.out.println(new Exception(e.getMessage()));
		}

		return cell1.getStringCellValue();
	}

	public static int getIterationCount(String ExcelName, String SheetName)
			throws Exception {

		getPath();
		FileInputStream fileInputStream = null;
		int UsedCellCount = 0;
		fileInputStream = new FileInputStream(gb_Str_Basepath + "TestData//"
				+ ExcelName);

		POIFSFileSystem fsFileSystem = new POIFSFileSystem(fileInputStream);

		workbook = new HSSFWorkbook((fsFileSystem));
		HSSFSheet sheet = workbook.getSheet(SheetName);
		UsedCellCount = sheet.getRow(0).getLastCellNum();

		return UsedCellCount - 2;
	}

	/*
	 * public WebElement GetwebLocators(WebDriver gb_Obj_Driver, String ObjName)
	 * throws Exception { WebElement element = null; String Locator; Locator =
	 * ObjName; // System.out.println(Locator); WebDriverWait wait = new
	 * WebDriverWait(gb_Obj_Driver, 100);
	 * wait.until(ExpectedConditions.visibilityOfElementLocated
	 * (By.id<locator>)); try { //
	 * System.out.println(Locator.contains("xpath="));
	 * 
	 * if (elementPresent == true) {
	 * 
	 * return 0; } if (second >= waittime && elementPresent == false) {
	 * 
	 * getPath(); create_Folder(); FailureScreenshotIterator++; String Title =
	 * gb_Obj_Driver.getTitle(); // String Title = gb_Obj_selenium.getTitle();
	 * String Path; Path = gb_Str_Basepath + "Result" +
	 * Driver_Script.gb_Str_Navi_Slash + Driver_Script.gb_Str_Os +
	 * Driver_Script.gb_Str_Navi_Slash + Driver_Script.gb_Str_TestcaseId +
	 * Driver_Script.gb_Str_Navi_Slash + "/FailureScreenshots_" +
	 * Driver_Script.gb_Str_TestcaseId + "_" + timestamp +
	 * Driver_Script.gb_Str_Navi_Slash + Title + FailureScreenshotIterator +
	 * ".png"; CaptureScreenshot(gb_Obj_Driver, Path); String FileName =
	 * "FailureScreenshots_" + Driver_Script.gb_Str_TestcaseId + "_" + timestamp
	 * + "\\" + Title + FailureScreenshotIterator + ".png";
	 * objxml.CreateReport(TestStepNumber, "The element " + objDesc +
	 * " Should be Present", "The element " + objDesc + "is not Present",
	 * "Fail", FileName); actionPerformed = false;
	 * 
	 * return 1;
	 * 
	 * if (Locator.startsWith("css=")) { Locator = Locator.substring(4);
	 * 
	 * wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(
	 * Locator)));
	 * if(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(Locator))
	 * == null) { getPath(); create_Folder(); FailureScreenshotIterator++;
	 * String Title = gb_Obj_Driver.getTitle(); // String Title =
	 * gb_Obj_selenium.getTitle(); String Path; Path = gb_Str_Basepath +
	 * "Result" + Driver_Script.gb_Str_Navi_Slash + Driver_Script.gb_Str_Os +
	 * Driver_Script.gb_Str_Navi_Slash + Driver_Script.gb_Str_TestcaseId +
	 * Driver_Script.gb_Str_Navi_Slash + "/FailureScreenshots_" +
	 * Driver_Script.gb_Str_TestcaseId + "_" + timestamp +
	 * Driver_Script.gb_Str_Navi_Slash + Title + FailureScreenshotIterator +
	 * ".png"; CaptureScreenshot(gb_Obj_Driver, Path); String FileName =
	 * "FailureScreenshots_" + Driver_Script.gb_Str_TestcaseId + "_" + timestamp
	 * + "\\" + Title + FailureScreenshotIterator + ".png";
	 * objxml.CreateReport("", "The element " + Locator + " Should be Present",
	 * "The element " + Locator + "is not Present", "Fail", FileName); } else
	 * 
	 * element = gb_Obj_Driver.findElement(By.cssSelector(Locator)); }
	 * 
	 * 
	 * //System.out.println(element); else if (Locator.startsWith("id=")) {
	 * Locator = Locator.substring(3);
	 * wait.until(ExpectedConditions.visibilityOfElementLocated
	 * (By.id(Locator)));
	 * if(ExpectedConditions.visibilityOfElementLocated(By.id(Locator)) == null)
	 * { getPath(); create_Folder(); FailureScreenshotIterator++; String Title =
	 * gb_Obj_Driver.getTitle(); // String Title = gb_Obj_selenium.getTitle();
	 * String Path; Path = gb_Str_Basepath + "Result" +
	 * Driver_Script.gb_Str_Navi_Slash + Driver_Script.gb_Str_Os +
	 * Driver_Script.gb_Str_Navi_Slash + Driver_Script.gb_Str_TestcaseId +
	 * Driver_Script.gb_Str_Navi_Slash + "/FailureScreenshots_" +
	 * Driver_Script.gb_Str_TestcaseId + "_" + timestamp +
	 * Driver_Script.gb_Str_Navi_Slash + Title + FailureScreenshotIterator +
	 * ".png"; CaptureScreenshot(gb_Obj_Driver, Path); String FileName =
	 * "FailureScreenshots_" + Driver_Script.gb_Str_TestcaseId + "_" + timestamp
	 * + "\\" + Title + FailureScreenshotIterator + ".png";
	 * objxml.CreateReport("", "The element " + Locator + " Should be Present",
	 * "The element " + Locator + "is not Present", "Fail", FileName); } else
	 * element = gb_Obj_Driver.findElement(By.id(Locator));
	 * 
	 * }
	 * 
	 * else if (Locator.startsWith("xpath=")) { //
	 * System.out.println(Locator.contains("xpath=")); Locator =
	 * Locator.substring(6);
	 * wait.until(ExpectedConditions.visibilityOfElementLocated
	 * (By.xpath(Locator)));
	 * if(ExpectedConditions.visibilityOfElementLocated(By.xpath(Locator)) ==
	 * null) { getPath(); create_Folder(); FailureScreenshotIterator++; String
	 * Title = gb_Obj_Driver.getTitle(); // String Title =
	 * gb_Obj_selenium.getTitle(); String Path; Path = gb_Str_Basepath +
	 * "Result" + Driver_Script.gb_Str_Navi_Slash + Driver_Script.gb_Str_Os +
	 * Driver_Script.gb_Str_Navi_Slash + Driver_Script.gb_Str_TestcaseId +
	 * Driver_Script.gb_Str_Navi_Slash + "/FailureScreenshots_" +
	 * Driver_Script.gb_Str_TestcaseId + "_" + timestamp +
	 * Driver_Script.gb_Str_Navi_Slash + Title + FailureScreenshotIterator +
	 * ".png"; CaptureScreenshot(gb_Obj_Driver, Path); String FileName =
	 * "FailureScreenshots_" + Driver_Script.gb_Str_TestcaseId + "_" + timestamp
	 * + "\\" + Title + FailureScreenshotIterator + ".png";
	 * objxml.CreateReport("", "The element " + Locator + " Should be Present",
	 * "The element " + Locator + "is not Present", "Fail", FileName); } else
	 * element = gb_Obj_Driver.findElement(By.xpath(Locator));
	 * 
	 * 
	 * } else if (Locator.startsWith("name=")) { Locator = Locator.substring(5);
	 * wait
	 * .until(ExpectedConditions.visibilityOfElementLocated(By.name(Locator)));
	 * if(ExpectedConditions.visibilityOfElementLocated(By.name(Locator)) ==
	 * null) { getPath(); create_Folder(); FailureScreenshotIterator++; String
	 * Title = gb_Obj_Driver.getTitle(); // String Title =
	 * gb_Obj_selenium.getTitle(); String Path; Path = gb_Str_Basepath +
	 * "Result" + Driver_Script.gb_Str_Navi_Slash + Driver_Script.gb_Str_Os +
	 * Driver_Script.gb_Str_Navi_Slash + Driver_Script.gb_Str_TestcaseId +
	 * Driver_Script.gb_Str_Navi_Slash + "/FailureScreenshots_" +
	 * Driver_Script.gb_Str_TestcaseId + "_" + timestamp +
	 * Driver_Script.gb_Str_Navi_Slash + Title + FailureScreenshotIterator +
	 * ".png"; CaptureScreenshot(gb_Obj_Driver, Path); String FileName =
	 * "FailureScreenshots_" + Driver_Script.gb_Str_TestcaseId + "_" + timestamp
	 * + "\\" + Title + FailureScreenshotIterator + ".png";
	 * objxml.CreateReport("", "The element " + Locator + " Should be Present",
	 * "The element " + Locator + "is not Present", "Fail", FileName); } else
	 * element = gb_Obj_Driver.findElement(By.name(Locator));
	 * 
	 * 
	 * } else if (Locator.startsWith("link=")) { Locator = Locator.substring(5);
	 * 
	 * 
	 * wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(Locator
	 * )));
	 * if(ExpectedConditions.visibilityOfElementLocated(By.linkText(Locator)) ==
	 * null) { getPath(); create_Folder(); FailureScreenshotIterator++; String
	 * Title = gb_Obj_Driver.getTitle(); // String Title =
	 * gb_Obj_selenium.getTitle(); String Path; Path = gb_Str_Basepath +
	 * "Result" + Driver_Script.gb_Str_Navi_Slash + Driver_Script.gb_Str_Os +
	 * Driver_Script.gb_Str_Navi_Slash + Driver_Script.gb_Str_TestcaseId +
	 * Driver_Script.gb_Str_Navi_Slash + "/FailureScreenshots_" +
	 * Driver_Script.gb_Str_TestcaseId + "_" + timestamp +
	 * Driver_Script.gb_Str_Navi_Slash + Title + FailureScreenshotIterator +
	 * ".png"; CaptureScreenshot(gb_Obj_Driver, Path); String FileName =
	 * "FailureScreenshots_" + Driver_Script.gb_Str_TestcaseId + "_" + timestamp
	 * + "\\" + Title + FailureScreenshotIterator + ".png";
	 * objxml.CreateReport("", "The element " + Locator + " Should be Present",
	 * "The element " + Locator + "is not Present", "Fail", FileName); } else
	 * element = gb_Obj_Driver.findElement(By.linkText(Locator));
	 * 
	 * }else {
	 * 
	 * element =
	 * (WebElement)((JavascriptExecutor)gb_Obj_Driver).executeScript(Locator); }
	 * } catch (Exception e) { String Pagetitle = gb_Obj_Driver.getTitle();
	 * System.out.println(Pagetitle); Pagetitle = Pagetitle.replaceAll(":",
	 * "_");
	 * 
	 * =Capturescreenshot(driver,"Bp_monthly",ObjName)+ObjName; gbsStatus=false;
	 * gboStatus=false;
	 * 
	 * System.out.println(e); //
	 * Reportlog(i,"Verify the \'"+ObjName+"\' Component/Value is valid"
	 * ,"The \'"+ObjName+"\' Component/Value should be valid","The \'"+ObjName+
	 * "\' Component/Value is invalid"
	 * ,gbsStatus,gsScreenshotName,gsResultsfile); gb_Obj_Driver.quit(); } //
	 * System.out.println(element); return element; }
	 */

	public WebElement GetwebLocators(WebDriver gb_Obj_Driver, String ObjName)
			throws Exception {
		WebElement element = null;
		String Locator;
		Locator = ObjName;
		WebDriverWait wait = new WebDriverWait(gb_Obj_Driver, 100);
		// System.out.println(Locator);

		try {

			if (Locator.startsWith("css=")) {
				Locator = Locator.substring(4);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By
						.cssSelector(Locator)));
				element = gb_Obj_Driver.findElement(By.cssSelector(Locator));
				// System.out.println(element);
			} else if (Locator.startsWith("id=")) {
				Locator = Locator.substring(3);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By
						.id(Locator)));
				element = gb_Obj_Driver.findElement(By.id(Locator));
			} else if (Locator.startsWith("xpath=")) {
				// System.out.println(Locator.contains("xpath="));
				Locator = Locator.substring(6);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By
						.xpath(Locator)));
				element = gb_Obj_Driver.findElement(By.xpath(Locator));

			} else if (Locator.startsWith("name=")) {
				Locator = Locator.substring(5);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By
						.name(Locator)));
				element = gb_Obj_Driver.findElement(By.name(Locator));
			} else if (Locator.startsWith("link=")) {
				Locator = Locator.substring(5);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By
						.linkText(Locator)));
				element = gb_Obj_Driver.findElement(By.linkText(Locator));
			} else if (Locator.startsWith("class=")) {
				Locator = Locator.substring(6);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By
						.className(Locator)));
				element = gb_Obj_Driver.findElement(By.className(Locator));
			} else {
				element = (WebElement) ((JavascriptExecutor) gb_Obj_Driver)
						.executeScript(Locator);
			}
		} catch (Exception e) {
			return null;
		}
		// System.out.println(element);
		return element;
	}

	public static void Switch_To_ChildFrame(WebDriver gb_Obj_Driver)
			throws Exception {
		try {
			gb_Obj_Driver.switchTo().defaultContent();
			gb_Obj_Driver.switchTo().frame("isaTop");
			gb_Obj_Driver.switchTo().frame("form_input");
		} catch (Exception e) {
		}
	}

	public static void Switch_To_HeaderFrame(WebDriver gb_Obj_Driver)
			throws Exception {
		try {
			gb_Obj_Driver.switchTo().defaultContent();
			gb_Obj_Driver.switchTo().frame("isaTop");
			gb_Obj_Driver.switchTo().frame("header");
		} catch (Exception e) {
		}
	}
}
