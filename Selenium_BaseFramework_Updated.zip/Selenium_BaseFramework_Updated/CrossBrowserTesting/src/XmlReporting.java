import java.io.BufferedReader;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.ProcessingInstruction;

public class XmlReporting {
	String timestamp;
	BufferedReader bf;
	String mainroot = "REPORT_LOG";
	String root = "LOG_ENTRY";
	Element mainrootElement, rootElement;
	Document document;
	DocumentBuilder documentBuilder;
	DocumentBuilderFactory documentBuilderFactory;
	String element;
	String data;
	int intdata;
	int serialNumber = 1;
	Element e;
	File directory;
	String BasePath;
	int location;
	String xmlsheetname;
	ProcessingInstruction PI;
	static File xmlFilePath;
	/*
	 * java.util.Date date= new java.util.Date(); java.sql.Timestamp
	 * timeStampDate = new Timestamp(date.getTimezoneOffset());
	 */
	DateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
	// get current date time with Date()
	Date date = new Date();

	public void InitializeReport(String Version, String Environment,
			String Browser, String TestcaseID) throws Exception {
		serialNumber = 1;
		timestamp = dateFormat.format(date).toString();
		directory = new File(".");
		String BasePath = directory.getCanonicalPath();
		// System.out.println(BasePath);
		location = BasePath.indexOf("CrossBrowserTesting");
		BasePath = BasePath.substring(0, location);
		String xsltPath = "XLST/LOG3.XSLT";

		// public static void main(String[] args) throws Exception {
		if (Driver_Script.gb_Str_Browser.toUpperCase().trim().equals("SAFARI")) {
			Driver_Script Driver = new Driver_Script();
			xmlsheetname = BasePath + "Result" +Driver.gb_Str_Navi_Slash + Environment
					+ Driver.gb_Str_Navi_Slash + Driver_Script.gb_Str_TestcaseId + Driver.gb_Str_Navi_Slash + TestcaseID + "_"+ Browser + "_"
					+ Version + "_" + timestamp + ".xml";
		}
		else
		{
		xmlsheetname = BasePath + "Result" +"\\" + Environment
				+ "\\" + Driver_Script.gb_Str_TestcaseId + "\\" + TestcaseID + "_"+ Browser + "_"
				+ Version + "_" + timestamp + ".xml";
		}
		System.out.print("xml report path" + xmlsheetname);
		xmlFilePath = new File(xmlsheetname);

		if (!xmlFilePath.exists()) {
			bf = new BufferedReader(new InputStreamReader(System.in));
			// System.out.println(check[0]);

			documentBuilderFactory = DocumentBuilderFactory.newInstance();
			documentBuilder = documentBuilderFactory.newDocumentBuilder();
			document = documentBuilder.newDocument();

			PI = document.createProcessingInstruction("xml-stylesheet",
					"href=\"" + xsltPath + "\"" + " type=" + "\"" + "text/XSL"
							+ "\"" + " target=\"_blank\"");
			document.appendChild((Node) PI);
			mainrootElement = document.createElement(mainroot);
			document.appendChild(mainrootElement);

			element = "Environment";
			e = document.createElement(element);
			e.appendChild(document.createTextNode(Environment));
			mainrootElement.appendChild(e);

			element = "TestcaseID";
			e = document.createElement(element);
			e.appendChild(document.createTextNode(TestcaseID));
			mainrootElement.appendChild(e);

			element = "Version";
			e = document.createElement(element);
			e.appendChild(document.createTextNode(Version));
			mainrootElement.appendChild(e);

			element = "Browser";
			e = document.createElement(element);
			e.appendChild(document.createTextNode(Browser));
			mainrootElement.appendChild(e);
			// System.out.println(mainroot);

			TransformerFactory transformerFactory = TransformerFactory
					.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(document);
			StringWriter sw = new StringWriter();
			StreamResult result = new StreamResult(sw);

			transformer.transform(source, result);
			String xmlString = sw.toString();

			// File file = new File(xmlFilePath);
			// FileUtils.copyFileToDirectory(BasePath+, destDir)
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(
					new FileOutputStream(xmlsheetname)));
			bw.write(xmlString);
			bw.flush();
			bw.close();
		}
	}

	// testcaseId, "Setting value in the"+objReadableName,
	// "value setted in the "+objReadableName,
	// "value setted in the"+objReadableName,"", applicationName, ""
	public void CreateReport(String testStepNumber, String Expected,
			String Actual, String Result, String screenshotPath)
			throws Exception {

		System.out.println(screenshotPath);
		rootElement = document.createElement(root);
		mainrootElement.appendChild(rootElement);

		element = "Sl.No";
		intdata = serialNumber++;

		e = document.createElement(element);
		data = new Integer(intdata).toString();
		e.appendChild(document.createTextNode(data));
		rootElement.appendChild(e);
		
		element = "TestCaseId";
		data = testStepNumber;
		e = document.createElement(element);
		e.appendChild(document.createTextNode(data));
		rootElement.appendChild(e);

		element = "Actual";
		data = Actual;
		e = document.createElement(element);
		e.appendChild(document.createTextNode(data));
		rootElement.appendChild(e);

		element = "Expected";
		data = Expected;
		e = document.createElement(element);
		e.appendChild(document.createTextNode(data));
		rootElement.appendChild(e);

		element = "IMAGE_PATH";
		data = screenshotPath;
		e = document.createElement(element);
		e.appendChild(document.createTextNode(data));
		rootElement.appendChild(e);

		element = "Result";
		data = Result;
		e = document.createElement(element);
		e.appendChild(document.createTextNode(data));
		rootElement.appendChild(e);

		//
		TransformerFactory transformerFactory = TransformerFactory
				.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(document);
		StringWriter sw = new StringWriter();
		StreamResult result = new StreamResult(sw);

		transformer.transform(source, result);
		String xmlString = sw.toString();

		// File file = new File(xmlFilePath);
		// FileUtils.copyFileToDirectory(BasePath+, destDir)
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(
				new FileOutputStream(xmlsheetname)));
		bw.write(xmlString);
		bw.flush();
		bw.close();
	}
}









