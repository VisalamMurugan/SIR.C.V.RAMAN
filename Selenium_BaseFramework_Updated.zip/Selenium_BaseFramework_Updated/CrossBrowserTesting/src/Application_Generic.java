import org.openqa.selenium.WebDriver;

import com.thoughtworks.selenium.DefaultSelenium;

public class Application_Generic extends FunctionalLibrary {
	static int[] a = new int[1];
	static boolean actionperformed = false;

	public boolean Login(WebDriver gb_Obj_Driver,
			String obj_login_text, String obj_password_text, String login_text,
			String password_text, String obj_login_button,
			int gb_Int_Teststepnumber) throws Exception {
		try {
			/*a[WaitForElementPresent(obj_login_text, gb_Int_Teststepnumber + "",
					"Login Page", gb_Obj_Driver)] = 0;*/

			IsElementPresent(obj_login_text, gb_Obj_Driver,
					gb_Int_Teststepnumber + "", "Login Page is displayed",
					"Login Page should be displayed",
					"Login Page is  not displayed");

			SetText(obj_login_text, "Username Text Field", login_text,
					gb_Int_Teststepnumber + "", gb_Obj_Driver);

			SetText(obj_password_text, "Password Text Field", password_text,
					gb_Int_Teststepnumber + "", gb_Obj_Driver);

			Click(obj_login_button, "Login button", gb_Int_Teststepnumber + "",
					gb_Obj_Driver);

			actionperformed = true;
		} catch (Exception e) {
			System.out.println("In catch Login");
		}
		return actionperformed;
	}

	public void Logoff(WebDriver gb_Obj_Driver, String obj_logoff,
			String obj_login_text, int gb_Int_Teststepnumber) throws Exception {

		try {
			a[WaitForElementPresent(obj_logoff, gb_Int_Teststepnumber + "",
					" Log Off Link", gb_Obj_Driver)] = 0;

			ClickSafari(obj_logoff, "Logoff link", gb_Int_Teststepnumber + "",
					gb_Obj_Driver);
			/*
			 * ConfirmationDialog(gb_Obj_selenium, gb_Int_Teststepnumber + "",
			 * "Confirmation dialog box is displayed",
			 * "Confirmation Dialog should be dispalyed",
			 * "Confirmation dialog is not displayed");
			 */

			Thread.sleep(15000);
			a[WaitForElementPresent(obj_login_text, gb_Int_Teststepnumber + "",
					"Login Text box", gb_Obj_Driver)] = 0;

			writeReport(gb_Int_Teststepnumber + "",
					"Log off from the application", "Successfully logged off",
					"Pass");
		}

		catch (Exception e) {
			writeReport(gb_Int_Teststepnumber + "",
					"Log off from the application",
					"Not Successfully logged off", "Fail");
		}

	}
}
