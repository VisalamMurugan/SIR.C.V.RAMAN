import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

public class Read_Testcase_Configuration {

	static File directory;
	public static String BasePath;
	static int location;
	// S&C_Testcase
	public String exec_SC01, exec_SC02, exec_HFS03,
			exec_HFS04, exec_HLS01, exec_HLS04, exec_HLS02,exec_HLS05,exec_HLS06,exec_SC04,
			exec_SC03, exec_HFS05, exec_HFS02, exec_HFS01, exec_HLS03;

	public static void getPath() throws Exception {
		directory = new File(".");

		BasePath = directory.getCanonicalPath();
		location = BasePath.indexOf("CrossBrowserTesting");
		BasePath = BasePath.substring(0, location);

	}

	public void testdata_Read() throws Exception, Exception {
		getPath(); // driver.get("http://qaweb01.invoicecentral.com");

		HSSFWorkbook workbook;
		HSSFCell cell, cell1;
		HSSFRow row;
		int iterator;
		int ln_Hfs_UsedCellCount = 0;
		
		int ln_Sc_UsedCellCount = 0;
		int ln_Hls_UsedCellCount = 0;
		
		System.out.println(BasePath);
		FileInputStream fileInputStream = new FileInputStream(BasePath
				+ "TestData//Testcase_Configuration.xls");

		POIFSFileSystem fsFileSystem = new POIFSFileSystem(fileInputStream);

		workbook = new HSSFWorkbook((fsFileSystem));


		HSSFSheet sheet4 = workbook.getSheet("HFS_Testcase");
		HSSFSheet sheet3 = workbook.getSheet("HLS_Testcase");
     	HSSFSheet sheet = workbook.getSheet("S&C_Testcase");

		ln_Hfs_UsedCellCount = sheet4.getLastRowNum();
		ln_Hls_UsedCellCount = sheet3.getLastRowNum();
	    ln_Sc_UsedCellCount = sheet.getLastRowNum();

		
		// HFS Test Cases

		for (iterator = 1; iterator <= (ln_Hfs_UsedCellCount); iterator++) {

			row = sheet4.getRow(iterator);
			cell = row.getCell(0);
			cell1 = row.getCell(1);

			if (cell.getStringCellValue().trim().equals("HFS01"))

			{
				cell1 = row.getCell(1);
				exec_HFS01 = cell1.getStringCellValue();

				continue;
			}

			if (cell.getStringCellValue().trim().equals("HFS02"))

			{
				cell1 = row.getCell(1);
				exec_HFS02 = cell1.getStringCellValue();

				continue;
			}
			if (cell.getStringCellValue().trim().equals("HFS03"))

			{
				cell1 = row.getCell(1);
				exec_HFS03 = cell1.getStringCellValue();

				continue;
			}
			if (cell.getStringCellValue().trim().equals("HFS04"))

			{
				cell1 = row.getCell(1);
				exec_HFS04 = cell1.getStringCellValue();

				continue;
			}
			if (cell.getStringCellValue().trim().equals("HFS05")) {

				cell1 = row.getCell(1);
				exec_HFS05 = cell1.getStringCellValue();

				continue;
			}

		}

		// HLS Test Cases

		for (iterator = 1; iterator <= (ln_Hls_UsedCellCount); iterator++) {
			row = sheet3.getRow(iterator);
			cell = row.getCell(0);
			cell1 = row.getCell(1);
			if (cell.getStringCellValue().trim().equals("HLS01")) {

				cell1 = row.getCell(1);
				exec_HLS01 = cell1.getStringCellValue();
				continue;
			}

			if (cell.getStringCellValue().trim().equals("HLS02"))

			{
				cell1 = row.getCell(1);
				exec_HLS02 = cell1.getStringCellValue();

				continue;
			}
			if (cell.getStringCellValue().trim().equals("HLS03"))

			{
				cell1 = row.getCell(1);
				exec_HLS03 = cell1.getStringCellValue();

				continue;
			}
			if (cell.getStringCellValue().trim().equals("HLS04"))

			{
				cell1 = row.getCell(1);
				exec_HLS04 = cell1.getStringCellValue();
				continue;
			}
			if (cell.getStringCellValue().trim().equals("HLS05"))

			{
				cell1 = row.getCell(1);
				exec_HLS05 = cell1.getStringCellValue();

				continue;
			}
			if (cell.getStringCellValue().trim().equals("HLS06"))

			{
				cell1 = row.getCell(1);
				exec_HLS06 = cell1.getStringCellValue();
				continue;
			}
		}
		// S&C Test Cases


			for (iterator = 1; iterator <= (ln_Sc_UsedCellCount); iterator++) {
				row = sheet.getRow(iterator);
				cell = row.getCell(0);
				cell1 = row.getCell(1);
				
				if (cell.getStringCellValue().trim().equals("S&C01")) {
					cell1 = row.getCell(1);
					exec_SC01 = cell1.getStringCellValue();

					continue;
				}

				if (cell.getStringCellValue().equals("S&C02"))

				{
					cell1 = row.getCell(1);
					exec_SC02 = cell1.getStringCellValue();

					continue;
				}
				if (cell.getStringCellValue().equals("S&C03"))

				{
					cell1 = row.getCell(1);
					exec_SC03 = cell1.getStringCellValue();
					continue;
				}
				if (cell.getStringCellValue().equals("S&C04"))

				{
					cell1 = row.getCell(1);
					exec_SC04 = cell1.getStringCellValue();

					continue;
				}

			}

		}

	}

