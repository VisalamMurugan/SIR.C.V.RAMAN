import org.openqa.selenium.WebDriver;

import com.thoughtworks.selenium.SeleniumException;

public class Sc04_TestScript extends FunctionalLibrary 
{
	static int[] a = new int[1];
	Application_Generic Application_Generic1 = new Application_Generic();
	public static int gb_Int_Teststepnumber = 0 ;

	public void Sc_04_TestScript(WebDriver gb_Obj_Driver,
			String gb_Str_Os, String gb_Str_Browser, String gb_Str_Version,
			String gb_Str_ExecutionStatus) throws Exception {
		try {
			gb_Int_Teststepnumber = 0;
			gb_Int_Teststepnumber = gb_Int_Teststepnumber + 1;
			/*gb_Obj_selenium.start();
			WindowFocus(gb_Obj_selenium);
			WindowMaximize(gb_Obj_selenium);
			gb_Obj_selenium.deleteAllVisibleCookies();

			open(gb_Obj_selenium, getLocator("Application", "DT_S&C_Url"));*/
			
			gb_Obj_Driver.manage().deleteAllCookies();
			gb_Obj_Driver.get(getLocator("Application", "DT_S&C_Url"));
			gb_Obj_Driver.manage().window().maximize();

			FunctionalLibrary.certificate(gb_Obj_Driver, gb_Str_Browser);
			CreateXml(gb_Str_Version, gb_Str_Os, gb_Str_Browser, "S&C04");
			
			Application_Generic1.Login(gb_Obj_Driver,
			getLocator("Application", "DT_S&C_Username"),
					getLocator("Application", "DT_S&C_Password"),
					getValue("Application", "DT_S&C_Username"),
					getValue("Application", "DT_S&C_Password"),
					getLocator("Application", "DT_S&C_Login_Button"),
					gb_Int_Teststepnumber);

			gb_Int_Teststepnumber = gb_Int_Teststepnumber + 1;
			
		
			
			a[WaitForElementPresent(getLocator("S&C01", "DT_Shop_Link"),
					gb_Int_Teststepnumber + "", "Shop Link", gb_Obj_Driver)] = 0;

			IsElementPresent(getLocator("S&C01", "DT_Shop_Link"),
					gb_Obj_Driver, gb_Int_Teststepnumber + "",
					"Shop Selection page is displayed",
					"Shop Selection page should be displayed",
					"Shop Selection page is  not displayed");

			Click(getLocator("S&C01", "DT_Shop_Link"), "Shop Link",
					gb_Int_Teststepnumber + "", gb_Obj_Driver);

			gb_Int_Teststepnumber = gb_Int_Teststepnumber + 1;

			
			
			a[WaitForElementPresent(getLocator("S&C04", "DT_Partner_Link"),
					gb_Int_Teststepnumber + "", "Partner Link", gb_Obj_Driver)] = 0;

			IsElementPresent(getLocator("S&C04", "DT_Partner_Link"),
					gb_Obj_Driver, gb_Int_Teststepnumber + "",
					"Partner Selection page is displayed",
					"Partner Selection page should be displayed",
					"Partner Selection page is  not displayed");

			Click(getLocator("S&C04", "DT_Partner_Link"), "Partner Link",
					gb_Int_Teststepnumber + "", gb_Obj_Driver);

			gb_Int_Teststepnumber = gb_Int_Teststepnumber + 1;

			
			
			a[WaitForElementPresent(getLocator("S&C04", "DT_Catalog_Link"),
					gb_Int_Teststepnumber + "", "Catalog Link",
					gb_Obj_Driver)] = 0;

			IsElementPresent(getLocator("S&C04", "DT_Catalog_Link"),
					gb_Obj_Driver, gb_Int_Teststepnumber + "",
					"Catalog Selection page is displayed",
					"Catalog Selection page should be displayed",
					"Catalog Selection page is  not displayed");

			Click(getLocator("S&C04", "DT_Catalog_Link"), "catalog Link",
					gb_Int_Teststepnumber + "", gb_Obj_Driver);

			gb_Int_Teststepnumber = gb_Int_Teststepnumber + 1;
			
			Switch_To_ChildFrame(gb_Obj_Driver);
			
		
			Thread.sleep(3000);
			
			a[WaitForElementPresent(getLocator("S&C04", "DT_Switch_Products"),
					gb_Int_Teststepnumber + "", "Switch Products Image Link",
					gb_Obj_Driver)] = 0;

			IsElementPresent(getLocator("S&C04", "DT_Switch_Products"),
					gb_Obj_Driver, gb_Int_Teststepnumber + "",
					"Home  page is displayed",
					"Home page should be displayed",
					"Home page is  not displayed");

		
			Thread.sleep(5000);
			System.out.println("b4 switch prod");
			Click(getLocator("S&C04", "DT_Switch_Products"), "Switch Products Image Link",
					gb_Int_Teststepnumber + "", gb_Obj_Driver);

			gb_Int_Teststepnumber = gb_Int_Teststepnumber + 1;
			
			
			Thread.sleep(5000);
			
			a[WaitForElementPresent(getLocator("S&C04", "DT_Switches"),
					gb_Int_Teststepnumber + "", "Switches Link", gb_Obj_Driver)] = 0;

			IsElementPresent(getLocator("S&C04", "DT_Switches"),
					gb_Obj_Driver, gb_Int_Teststepnumber + "",
					"Catalog page is displayed",
					"Catalog page should be displayed",
					"Catalog page is  not displayed");


			System.out.println("b4 switch ");
			
			Thread.sleep(5000);
			
			Click(getLocator("S&C04", "DT_Switches"), "Switches Link",
					gb_Int_Teststepnumber + "", gb_Obj_Driver);

			gb_Int_Teststepnumber = gb_Int_Teststepnumber + 1;


			System.out.println("b4 sealed switch");
			
			Thread.sleep(5000);
			
			a[WaitForElementPresent(getLocator("S&C04", "DT_Sealed_Switches"),
					gb_Int_Teststepnumber + "", "Sealed Switches Link", gb_Obj_Driver)] = 0;

			Click(getLocator("S&C04", "DT_Sealed_Switches"), "Sealed Switches Link",
					gb_Int_Teststepnumber + "", gb_Obj_Driver);

		
			Thread.sleep(5000);
			
			a[WaitForElementPresent(getLocator("S&C04", "DT_Military_Grade"),
					gb_Int_Teststepnumber + "", "Military Goggles Link", gb_Obj_Driver)] = 0;
			
			Click(getLocator("S&C04", "DT_Military_Grade"), "Military Goggles Link",
					gb_Int_Teststepnumber + "", gb_Obj_Driver);

			System.out.println("b4 military grade");
			
			Thread.sleep(6000);
			
			a[WaitForElementPresent(getLocator("S&C04", "DT_Chec_Box"),
					gb_Int_Teststepnumber + "", "Item checkbox", gb_Obj_Driver)] = 0;
			
			IsElementPresent(getLocator("S&C04", "DT_Switches"),
					gb_Obj_Driver, gb_Int_Teststepnumber + "",
					"Military Grade toggle switches is displayed",
					"Military Grade toggle switches should be displayed",
					"Military Grade toggle switches is  not displayed");
		
			
			Click(getLocator("S&C04", "DT_Chec_Box"),
					"Item checkbox", gb_Int_Teststepnumber + "",
					gb_Obj_Driver);
			
			Click(getLocator("S&C04", "DT_AddTo_Cart_Button"),
					"Add To Cart button", gb_Int_Teststepnumber + "",
					gb_Obj_Driver);

			gb_Int_Teststepnumber = gb_Int_Teststepnumber + 1;

			Thread.sleep(3000);
			
			a[WaitForElementPresent(getLocator("S&C04", "DT_Continue_Button"),
					gb_Int_Teststepnumber + "", "Continue Button", gb_Obj_Driver)] = 0;

			IsElementPresent(getLocator("S&C04", "DT_Continue_Button"),
					gb_Obj_Driver, gb_Int_Teststepnumber + "",
					"Order Selection page is displayed",
					"Order Selection page should be displayed",
					"Order Selection page is  not displayed");

			Click(getLocator("S&C04", "DT_Continue_Button"),
					"Continue button", gb_Int_Teststepnumber + "",
					gb_Obj_Driver);

			gb_Int_Teststepnumber = gb_Int_Teststepnumber + 1;
			
			//Switch_To_HeaderFrame(gb_Obj_Driver);
			
	
			
		/*	String VerificationText2 = null;
			
			for(int i=0;i<10;i++)
			{
				 VerificationText2 = getText((getLocator("S&C04","DT_MiniShopping_Link")),gb_Obj_Driver);
				if(! VerificationText2.contains("0 ITEMS"))
				{
					break;
				}
				Thread.sleep(5000);
				
			}
			
			Thread.sleep(10000);
			
			Click("link="+VerificationText2,
					"Mini Shopping basket Icon" , gb_Int_Teststepnumber + "",
					gb_Obj_Driver);*/
			
			//Switch_To_ChildFrame(gb_Obj_Driver);
			
			//Thread.sleep(10000);
			/*
			a[WaitForElementPresent(
					getLocator("S&C04", "DT_Reference_Text"),
					gb_Int_Teststepnumber + "", "Reference TextField",
					gb_Obj_Driver)] = 0;

			IsElementPresent(getLocator("S&C04", "DT_Reference_Text"),
					gb_Obj_Driver, gb_Int_Teststepnumber + "",
					"Items in Catalog Area is moved to Shopping basket",
					"Items in Catalog Area should be moved to Shopping basket",
					"Items in Catalog Area is not moved to Shopping basket");
			
			gb_Int_Teststepnumber = gb_Int_Teststepnumber + 1;*/
			
			Switch_To_HeaderFrame(gb_Obj_Driver);
			
			//Thread.sleep(10000);
			
			Application_Generic1.Logoff(gb_Obj_Driver,
					getLocator("S&C04","DT_Log_Off"),
					getLocator("Application","DT_S&C_Username"),
					gb_Int_Teststepnumber);
			Close(gb_Obj_Driver);

			gb_Obj_Driver.quit();

		}
		catch (ArrayIndexOutOfBoundsException e) {
			gb_Int_Teststepnumber = gb_Int_Teststepnumber + 1;
			
			Switch_To_HeaderFrame(gb_Obj_Driver);
			Application_Generic1.Logoff(gb_Obj_Driver,

			getLocator("S&C04", "DT_Log_Off"),
					getLocator("Application", "DT_S&C_Username"),
					gb_Int_Teststepnumber);
			Close(gb_Obj_Driver);
			gb_Obj_Driver.quit();
			return;
		} catch (SeleniumException e) {
			gb_Int_Teststepnumber = gb_Int_Teststepnumber + 1;
			
			Switch_To_HeaderFrame(gb_Obj_Driver);
			Application_Generic1.Logoff(gb_Obj_Driver,

			getLocator("S&C04", "DT_Log_Off"),
					getLocator("Application", "DT_S&C_Username"),
					gb_Int_Teststepnumber);
			Close(gb_Obj_Driver);
			gb_Obj_Driver.quit();
			return;
		}

	}
}
