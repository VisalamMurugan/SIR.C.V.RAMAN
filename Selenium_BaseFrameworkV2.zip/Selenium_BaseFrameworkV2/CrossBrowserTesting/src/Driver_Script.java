import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Driver_Script {
	public Boolean gb_Bol_Verify;
	static Read_Browser_Configuration gb_Obj_BrowserConfiguration_Read;
	static FunctionalLibrary gb_Obj_Functionallibrary;
	static Read_Testcase_Configuration gb_Obj_ReadtestConfiguration;
	public static WebDriver gb_Obj_Driver;
	public static String gb_Str_BrowserType;
	static File gb_Obj_directory;
	public static String gb_Str_Basepath;
	static int gb_Int_Location;
	static String gb_Str_Browser, gb_Str_Version;
	static String gb_Str_Os;
	static String gb_Str_TestcaseId;
	static String gb_str_ManualStatus = "Yes";
	static String gb_Str_ExecutionStatus;
	static String gb_Str_Profile_Path;
	static String gb_Str_Navi_Slash;
	public static int gb_Int_Teststepnumber = 0;
	public String a;
	public static int Iterationcount = 0;
	public static int CurrentIteration = 0;

	public static void getPath() throws Exception {
		gb_Obj_directory = new File(".");

		gb_Str_Basepath = gb_Obj_directory.getCanonicalPath();
		gb_Int_Location = gb_Str_Basepath.indexOf("CrossBrowserTesting");
		gb_Str_Basepath = gb_Str_Basepath.substring(0, gb_Int_Location);
		System.out.println(gb_Str_Basepath);
	}

	public static void launchBrowser(String gb_Str_Browser) throws Exception {

		if (gb_Str_Browser.trim().equals("FF")) {
			FirefoxBinary binary = new FirefoxBinary(new File(
					gb_Str_Profile_Path));
			FirefoxProfile profile = new FirefoxProfile();
			
			profile.setPreference("security.ssl3.dhe_rsa_aes_128_sha", false);
			profile.setPreference("security.ssl3.dhe_rsa_aes_256_sha", false);
			
			gb_Obj_Driver = new FirefoxDriver(binary, profile);

			gb_Str_Navi_Slash = "\\";
			gb_Obj_Driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		}
		
		else if (gb_Str_Browser.trim().equals("IE")) {
			File file = new File(gb_Str_Basepath
							+ "\\Driver\\IEDriverServer_Win32_2.39.0\\IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
			gb_Obj_Driver = new InternetExplorerDriver();

			gb_Str_Navi_Slash = "\\";
			gb_Obj_Driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		}
		else if (gb_Str_Browser.trim().equals("GC")) {

			File file = new File(gb_Str_Basepath
					+ "\\Driver\\chromedriver_win32\\chromedriver.exe");

			System.setProperty("webdriver.chrome.driver",
					file.getAbsolutePath());
			// System.setProperty("webdriver.chrome.driver" + "--verbose",
			// file.getAbsolutePath() );

			gb_Obj_Driver = new ChromeDriver();
			gb_Str_Navi_Slash = "\\";
			gb_Obj_Driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		}

		

	}

	public static void main(String[] args) throws Exception {

		getPath();

		gb_Obj_BrowserConfiguration_Read = new Read_Browser_Configuration();
		int UsedCellCount = 0;
		int iterator;

		UsedCellCount = gb_Obj_BrowserConfiguration_Read
				.Read_BrowserConfiguartion();

		for (iterator = 1; iterator <= (UsedCellCount); iterator++) {
			gb_Str_Os = gb_Obj_BrowserConfiguration_Read.getcell_Stringvalue(
					iterator, 1);

			gb_Str_Browser = gb_Obj_BrowserConfiguration_Read
					.getcell_Stringvalue(iterator, 2);

			gb_Str_Version = gb_Obj_BrowserConfiguration_Read
					.getcell_Stringvalue(iterator, 3);

			gb_Str_Profile_Path = gb_Obj_BrowserConfiguration_Read
					.getcell_Stringvalue(iterator, 4);

			gb_Str_ExecutionStatus = gb_Obj_BrowserConfiguration_Read
					.getcell_Stringvalue(iterator, 5);

			if (gb_Str_ExecutionStatus.trim().toLowerCase().equals("yes")) {

				gb_Obj_Functionallibrary = new FunctionalLibrary();

				
				Sc04_TestScript ln_Obj_Sc04TestScript = new Sc04_TestScript();

				gb_Obj_ReadtestConfiguration = new Read_Testcase_Configuration();
				gb_Obj_ReadtestConfiguration.testdata_Read();
				FunctionalLibrary.getPath();

				if (gb_Obj_ReadtestConfiguration.exec_SC04.trim().toLowerCase()
						.equals("yes")) {
					gb_Str_TestcaseId = "S&C04";
					Iterationcount = 0;
					Iterationcount = FunctionalLibrary.getIterationCount(
							"S&C_Application_Input.xls", "S&C04");
					for (CurrentIteration = 0; CurrentIteration < Iterationcount; CurrentIteration++) {

						launchBrowser(gb_Str_Browser);
						FunctionalLibrary.check_Folder();
						FunctionalLibrary.check_Manual_SnapshotFolder();
						ln_Obj_Sc04TestScript.Sc_04_TestScript(gb_Obj_Driver,
								gb_Str_Os, gb_Str_Browser, gb_Str_Version,
								gb_Str_ExecutionStatus);
					}

				}

			}
			
		}
	}
}
